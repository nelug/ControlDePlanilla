module.exports = [
  'spec/javascripts/helpers/mocks.js',
  'spec/javascripts/unit/**/*_spec.js'
];
