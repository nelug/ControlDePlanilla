<?php

class Assigned_roles extends Eloquent {
	
}
