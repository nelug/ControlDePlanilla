<?php

class VentaController extends \BaseController {


}
